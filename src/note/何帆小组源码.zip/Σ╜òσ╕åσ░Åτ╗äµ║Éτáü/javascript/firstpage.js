//加按钮
function add() {
    var addbutton = document.getElementById("addbutton");
    var minusbutton = document.getElementById("minusbutton");
    var origin = document.getElementById("origin");
    var num = parseInt(origin.getAttribute("value"));
    num++;
    if (num > 13) {
        num = 13;
        alert("库存只剩" + num + '件')
    }
    origin.setAttribute("value", num);
    minusbutton.style.cursor = 'pointer';
}
//减按钮
function minus() {
    var minusbutton = document.getElementById("minusbutton");
    var origin = document.getElementById("origin");
    var num = parseInt(origin.getAttribute("value"));
    num--;
    if (num < 1) {
        minusbutton.style.cursor = 'not-allowed';
        num = 1;
    } else {
        minusbutton.style.cursor = 'pointer';
    }
    origin.setAttribute("value", num);
}

$(function() {
    //全部商品分类下拉模块
    $('#total_nav').on('mouseenter', function() {
            $('#navshow').stop(true, false).slideDown();
        }).on('mouseleave', function() {
            $('#navshow').stop(true, false).fadeOut();
        })
        //fixtool模块
    $(window).scroll(function() {
            var scrollTop = $(window).scrollTop();
            var j = Math.floor((scrollTop - 1300) / 270);
            if (scrollTop > 1300) {
                $('.fixtool').fadeIn();
                $('.fixtool>ul>li').eq(j).addClass('fixtoolhover').siblings('li').removeClass('fixtoolhover')
            } else {
                $('.fixtool').fadeOut();
            }
            $('.fixtool>ul>li').on('click', function() {
                var idx = $(this).index();
                window.scrollTo({
                    top: 1300 + 270 * idx
                })
            })
        })
        //导航栏     
    $('#myjd').on('mouseenter', function() {
        $(this).children('ul').show()
    }).on('mouseleave', function() {
        $(this).children('ul').hide()
    })
    $('#myqiye').on('mouseenter', function() {
        $(this).children('ul').show()
    }).on('mouseleave', function() {
        $(this).children('ul').hide()
    })
    $('#client_service').on('mouseenter', function() {
        $(this).children('ul').show()
    }).on('mouseleave', function() {
        $(this).children('ul').hide()
    })
    $('#web_nav').on('mouseenter', function() {
            $(this).children('div').show()
        }).on('mouseleave', function() {
            $(this).children('div').hide()
        })
        //京东秒杀
    $(window).scroll(function() {
            var scrollTop = $('.push_tuijian1').offset().top - 90;
            if ($(window).scrollTop() >= scrollTop) {
                $('.sky_window_wrap').stop(true, false).fadeIn(300);
            } else {
                $('.sky_window_wrap').stop(true, false).fadeOut(500);
            }
        })
        //左侧导航栏鼠标移入显示
    $('#navshow>ul>li').on('mouseenter', function() {
        var idx = $(this).index();
        $('#mainpage_items_show_wrap>div').eq(idx).show().siblings('div').hide();
    })
    $('#navshow>ul').on('mouseleave', function() {
        $('.mainpage_items_show').hide();
    })
})