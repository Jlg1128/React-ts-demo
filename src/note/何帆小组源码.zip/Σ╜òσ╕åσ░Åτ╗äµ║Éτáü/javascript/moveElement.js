function moveElement(elementID,final_x,final_y,interval){
    if(!document.getElementById(elementID)) return false;
    if(!document.getElementById) return false;
    var testmove=document.getElementById(elementID);
    if(!testmove.style.top){
        testmove.style.top="0px";
        alert('1')
    }
    if(!testmove.style.left){
        testmove.style.left="0px";
        alert('1')
    }
    if(testmove.movement){
        clearTimeout(testmove.movement)
    }
    var toppos=parseInt(testmove.style.top);
    var leftpos=parseInt(testmove.style.left);
    var dist=0;
    if(toppos==0&&leftpos==0) return true;
    if(toppos<final_y){
        dist=Math.ceil((final_y-toppos)/10);
        toppos+=dist;
    }
    if(toppos>final_y){ 
        dist=Math.ceil((toppos-final_y)/10);
        toppos-=dist;
    }
    if(leftpos<final_x){
        dist=Math.ceil((final_x-leftpos)/10);
        leftpos+=dist;
    }
    if(leftpos>final_x){
        dist=Math.ceil((leftpos-final_x)/10);
        leftpos-=dist;
    }

    testmove.style.top=toppos+"px";
    testmove.style.left=leftpos+"px";
    var repeat=" moveElement('"+elementID+"','"+final_x+"','"+final_y+"','"+interval+"')";
    testmove.movement=setTimeout(repeat,interval);
}