// function swiperitem(){
//     var swiper_img=document.getElementById("swiper_img");
//     var items=swiper_img.getElementsByTagName("img");
//     items[0].onmouseover=function(){
//         moveElement("swiper_item1",0,0,10);
//        }
//        items[1].onmouseover=function(){
//         moveElement("swiper_item1",-450,0,10)
//         moveElement("swiper_item2",0,0,10)
//        }
//        items[2].onmouseover=function(){
//         moveElement("swiper_item3",0,0,10);
//         moveElement("swiper_item1",0,0,10);
//        }

// }
// addLoadEvent(swiperitem);
// var index=0;
// function Changeimg(){
//    var preview_img=document.getElementById("preview_img");
//    var img=preview_img.getElementsByTagName("img");
//     if(index==img.length) index=0;
//     for(var i=0;i<img.length;i++){
//     img[i].style.display="none";
//   }
//   img[index].style.display="block";
//    index++;
// }
// setInterval(Changeimg,500)
//项目页轮播图模块
function borderappear(e){
    e.style.border="1px solid red";
}
function borderdisappear(e){
    e.style.border="1px solid transparent";
}
function bigger(){
    var origin=document.getElementById("preview_img").getElementsByTagName("img")[0];
    var links=document.getElementById("swiper_img").getElementsByTagName("img");
         for(var i=0;i<links.length;i++){
            links[i].index=i;
            links[i].onmouseover=function(){
                num=this.index+1;
                origin.src="./upload/images/product_show_"+num+".png";
                borderappear(this);
            }
        links[i].onmouseout=function(){
            borderdisappear(this);
        }

    }
}
var num=1;
function leftarrow(){
    num--;
   var links=document.getElementById("swiper_img").getElementsByTagName("img");
   var origin=document.getElementById("preview_img").getElementsByTagName("img")[0];
   if(num<1) num=5;
   if(num>5) num=1;
   origin.src="./upload/images/product_show_"+num+".png";
}
function rightarrow(){
    num++;
   var links=document.getElementById("swiper_img").getElementsByTagName("img");
   var origin=document.getElementById("preview_img").getElementsByTagName("img")[0];
   if(num<1) num=5;
   if(num>5) num=1;
   origin.src="./upload/images/product_show_"+num+".png";
}
//导航栏显示模块
// function showindex1nav(){
//     var items=document.getElementById("navshow");
//     items.style.display="block"
// }
// function hideindex1nav(){
//     var items=document.getElementById("navshow");
//     items.style.display="none"
// }
// function shownav(){
//     var total_nav=document.getElementById("total_nav");
//     total_nav.onmouseover=function(){
//         showindex1nav();
//     }
//     total_nav.onmouseout=function(){
//         hideindex1nav();
//     }
// }
//主页轮播图模块
var namy=0;
function arrow_lf(){
    var arrow_lf=document.getElementById("arrow_lf");
    var items=document.getElementById("circle").getElementsByTagName("li");

    arrow_lf.onclick=function(){
        clearInterval(timer);
        namy--;
        if(namy>6) namy=0;
        if(namy<0) namy=6;
        main_img.src="./upload/"+namy+".jpg";
for(var i=0;i<7;i++){
        items[i].style.backgroundColor='white';
    }
        items[namy].style.backgroundColor="black" ; 
    }
}
function arrow_ri(){
    var arrow_ri=document.getElementById("arrow_ri");
    var items=document.getElementById("circle").getElementsByTagName("li");
    arrow_ri.onclick=function(){  
        clearInterval(timer);
        namy++;
        if(namy>6) namy=0;
        if(namy<0) namy=6;
        main_img.src="./upload/"+namy+".jpg"
        for(var i=0;i<7;i++){
        items[i].style.backgroundColor="white";
        }
        items[namy].style.backgroundColor="black" ; 
    }
}
function ym(){
    alert(namy)
}
function autoRun(){
    namy++;
    var items=document.getElementById("circle").getElementsByTagName("li");
    var main_img=document.getElementById("main_img");
    if(namy>6) namy=0;
    if(namy<0) namy=6;
    if(namy === 4){
        main_img.onclick = function(){
            window.location.href = 'product_info.html'
        }
    }
    main_img.src="./upload/"+namy+".jpg"; 
    for(var i=0;i<=6;i++){
        items[i].style.backgroundColor="white";
    }
        items[namy].style.backgroundColor='black' 
}
var timer=setInterval(autoRun,2000);
function mainimgChangeNow(){
var main_img=document.getElementById("main_img");
var items=document.getElementById("circle").getElementsByTagName("li");
for(var i=0;i<=6;i++){
    items[0].style.backgroundColor="black";
    items[i].index=i;
    items[i].onmouseover=function(){
        clearInterval(timer);
        for(j=0;j<=6;j++){
            items[j].style.backgroundColor='white' ;
        }
        namy=this.index;
        main_img.src="./upload/"+namy+".jpg";  
        items[namy].style.backgroundColor='black' ;    
    }
    items[i].onmouseout=function(){
        namy=this.index;
        main_img.src="./upload/"+namy+".jpg";  
       timer=setInterval(autoRun,2000)
    }
        
}
}
window.onload=function(){
    shownav();
    mainimgChangeNow();
    arrow_lf();
    arrow_ri();
}
addLoadEvent(bigger);
