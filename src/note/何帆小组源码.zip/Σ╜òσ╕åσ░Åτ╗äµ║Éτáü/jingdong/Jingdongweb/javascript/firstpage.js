
//加按钮
function add() {
    var addbutton = document.getElementById("addbutton");
    var minusbutton = document.getElementById("minusbutton");
    var origin = document.getElementById("origin");
    var num = parseInt(origin.getAttribute("value"));
    num++;
    if (num > 13) {
        num = 13;
        alert("库存只剩" + num + '件')
    }
    origin.setAttribute("value", num);
    minusbutton.style.cursor = 'pointer';
}
//减按钮
function minus() {
    var minusbutton = document.getElementById("minusbutton");
    var origin = document.getElementById("origin");
    var num = parseInt(origin.getAttribute("value"));
    num--;
    if (num < 1) {
        minusbutton.style.cursor = 'not-allowed';
        num = 1;
    } else {
        minusbutton.style.cursor = 'pointer';
    }
    origin.setAttribute("value", num);
}

$(function () {
    //全部商品分类下拉模块
    $('#total_nav').on('mouseenter', function () {
        $('#navshow').stop(true, false).slideDown();
    }).on('mouseleave', function () {
        $('#navshow').stop(true, false).fadeOut();
    })
    //fixtool模块
    $(window).scroll(function () {
        var scrollTop = $(window).scrollTop();
        var j = Math.floor((scrollTop - 1300) / 270);
        if (scrollTop > 1300) {
            $('.fixtool').fadeIn();
            $('.fixtool>ul>li').eq(j).addClass('fixtoolhover').siblings('li').removeClass('fixtoolhover')
        } else {
            $('.fixtool').fadeOut();
        }
        $('.fixtool>ul>li').on('click', function () {
            var idx = $(this).index();
            window.scrollTo({
                top: 1300 + 270 * idx
            })
        })
    })
    //导航栏     
    $('#myjd').on('mouseenter', function () {
        $(this).children('ul').show()
    }).on('mouseleave', function () {
        $(this).children('ul').hide()
    })
    $('#myqiye').on('mouseenter', function () {
        $(this).children('ul').show()
    }).on('mouseleave', function () {
        $(this).children('ul').hide()
    })
    $('#client_service').on('mouseenter', function () {
        $(this).children('ul').show()
    }).on('mouseleave', function () {
        $(this).children('ul').hide()
    })
    $('#web_nav').on('mouseenter', function () {
        $(this).children('div').show()
    }).on('mouseleave', function () {
        $(this).children('div').hide()
    })
    //京东秒杀
    $(window).scroll(function () {
        var scrollTop = $('.push_tuijian1').offset().top - 90;
        if ($(window).scrollTop() >= scrollTop) {
            $('.sky_window_wrap').stop(true, false).fadeIn(300);
        } else {
            $('.sky_window_wrap').stop(true, false).fadeOut(500);
        }
    })
    //左侧导航栏鼠标移入显示
    $('#navshow>ul>li').on('mouseenter', function () {
        var idx = $(this).index();
        $('#mainpage_items_show_wrap>div').eq(idx).show().siblings('div').hide();
    })
    $('#navshow>ul').on('mouseleave', function () {
        $('.mainpage_items_show').hide();
    })
})


//轮播图
var namy = 0;
function autoRun() {
    namy++;
    var items = document.getElementById("circle").getElementsByTagName("li");
    var main_img = document.getElementById("main_img");
    if (namy > 6) namy = 0;
    if (namy < 0) namy = 6;
    main_img.src = "./upload/" + namy + ".jpg";
    for (var i = 0; i <= 6; i++) {
        items[i].style.backgroundColor = "white";
    }
    items[namy].style.backgroundColor = 'black'
}
var timer = setInterval(autoRun, 2000);

//品牌特价
let arrData = [0,1,2,3,4,5]
arrData.map((item, index) => {
   let newest =`<li>
    <a href="#">
        <img src="./upload/品牌_03.png" alt="">
        <h4>美好精品全在这里</h4>
    </a>
    </li>`
    document.getElementById("newest-ri-item-ul").innerHTML += newest
})

//每日特价
let tejia = [04,05,06,07]
tejia.map((item, index) => {
   let data =`<li>
   <a href="#">
       <img src="./upload/1_0${item}.png" alt="">
       <h3>玉祖糖鞋垫男留香型</h3>
       <p style="font-size: 15px;">￥15</p>
       <p>热卖中</p>
   </a>
</li>`
    document.getElementById("newest_2_lf_item-ul").innerHTML += data
})

//充话费
let huafei = ['huafei','baitiao','jipiao','jiudian','licai',
'jiayouka', 'youxi', 'dianyingpiao', 'zhongchou', 'qiyegou',
'lipinka', 'huochepiao'
]
huafei.map((item, index) => {
   let data =`<li>
   <a href="#">
       <i class="lifeservice_ico_${item}"></i>
       <p>话费</p>
   </a>
</li>`
    document.getElementById("lifeservice-ul").innerHTML += data
})

//品牌1
let mainpage_items_show_img = [1,2,3,4,5,6,7,8]
huafei.map((item, index) => {
   let data =`<li>
   <a href=""><img src="./images/p${item}.webp" alt="231"></a>
</li>`
    document.querySelector("mainpage_items_show_img").innerHTML += data
})

//产品详情
let product_nav_lists = [1,2,3,4,5,6,7,8]
product_nav_lists.map((item, index) => {
   let data =`<dl>
   <dt><a href=""><strong>电视 </strong> <i></i></a>
   </dt>
   <dd>
       <ul class="product_nav_lists">
           <li><a href="">超薄电视</a></li>
           <li><a href="">全面屏电视</a></li>
           <li><a href="">智能电视</a></li>
           <li><a href="">教育电视</a></li>
           <li><a href="">OLED电视</a></li>
           <li><a href="">智慧屏</a></li>
           <li><a href="">4K超清电视</a></li>
           <li><a href="">55英寸</a></li>
           <li><a href="">65英寸</a></li>
           <li><a href="">电视配件</a></li>
       </ul>
   </dd>
</dl>`
    document.querySelector("mainpage_items_show_img").innerHTML += data
})

