let dropDownLists = [1,2,3,4,5,6,7,8]
    dropDownLists.map((item, index) => {
    document.getElementById("mainpage_items_show_wrap").innerHTML += `
    <div class=" mainpage_items_show">
<div class="mainpage_items_show_left">
    <ul class="mainpage_items_show_head">
        <li><a href="">家电馆${index}<i></i></a></li>
        <li><a href="">家电专卖店<i></i></a></li>
        <li><a href="">家电服务<i></i></a></li>
        <li><a href="">企业采购<i></i></a></li>
        <li><a href="">商用电器<i></i></a></li>
        <li><a href="">以旧换新<i></i></a></li>
    </ul>
    <dl>
        <dt><a href=""><strong>电视 </strong> <i></i></a>
        </dt>
        <dd>
            <ul class="product_nav_lists">
                <li><a href="">超薄电视</a></li>
                <li><a href="">全面屏电视</a></li>
                <li><a href="">智能电视</a></li>
                <li><a href="">教育电视</a></li>
                <li><a href="">OLED电视</a></li>
                <li><a href="">智慧屏</a></li>
                <li><a href="">4K超清电视</a></li>
                <li><a href="">55英寸</a></li>
                <li><a href="">65英寸</a></li>
                <li><a href="">电视配件</a></li>
            </ul>
        </dd>
    </dl>
    <dl>
        <dt><a href=""><strong>电视 </strong> <i></i></a>
        </dt>
        <dd>
            <ul class="product_nav_lists">
                <li><a href="">超薄电视</a></li>
                <li><a href="">全面屏电视</a></li>
                <li><a href="">智能电视</a></li>
                <li><a href="">教育电视</a></li>
                <li><a href="">OLED电视</a></li>
                <li><a href="">智慧屏</a></li>
                <li><a href="">4K超清电视</a></li>
                <li><a href="">55英寸</a></li>
                <li><a href="">65英寸</a></li>
                <li><a href="">电视配件</a></li>
            </ul>
        </dd>
    </dl>
    <dl>
        <dt><a href=""><strong>电视 </strong> <i></i></a>
        </dt>
        <dd>
            <ul class="product_nav_lists">
                <li><a href="">超薄电视</a></li>
                <li><a href="">全面屏电视</a></li>
                <li><a href="">智能电视</a></li>
                <li><a href="">教育电视</a></li>
                <li><a href="">OLED电视</a></li>
                <li><a href="">智慧屏</a></li>
                <li><a href="">4K超清电视</a></li>
                <li><a href="">55英寸</a></li>
                <li><a href="">65英寸</a></li>
                <li><a href="">电视配件</a></li>
            </ul>
        </dd>
    </dl>
    <dl>
        <dt><a href=""><strong>电视 </strong> <i></i></a>
        </dt>
        <dd>
            <ul class="product_nav_lists">
                <li><a href="">超薄电视</a></li>
                <li><a href="">全面屏电视</a></li>
                <li><a href="">智能电视</a></li>
                <li><a href="">教育电视</a></li>
                <li><a href="">OLED电视</a></li>
                <li><a href="">智慧屏</a></li>
                <li><a href="">4K超清电视</a></li>
                <li><a href="">55英寸</a></li>
                <li><a href="">65英寸</a></li>
                <li><a href="">电视配件</a></li>
            </ul>
        </dd>
    </dl>
    <dl>
        <dt><a href=""><strong>电视 </strong> <i></i></a>
        </dt>
        <dd>
            <ul class="product_nav_lists">
                <li><a href="">超薄电视</a></li>
                <li><a href="">全面屏电视</a></li>
                <li><a href="">智能电视</a></li>
                <li><a href="">教育电视</a></li>
                <li><a href="">OLED电视</a></li>
                <li><a href="">智慧屏</a></li>
                <li><a href="">4K超清电视</a></li>
                <li><a href="">55英寸</a></li>
                <li><a href="">65英寸</a></li>
                <li><a href="">电视配件</a></li>
            </ul>
        </dd>
    </dl>
    <dl>
        <dt><a href=""><strong>电视 </strong> <i></i></a>
        </dt>
        <dd>
            <ul class="product_nav_lists">
                <li><a href="">超薄电视</a></li>
                <li><a href="">全面屏电视</a></li>
                <li><a href="">智能电视</a></li>
                <li><a href="">教育电视</a></li>
                <li><a href="">OLED电视</a></li>
                <li><a href="">智慧屏</a></li>
                <li><a href="">4K超清电视</a></li>
                <li><a href="">55英寸</a></li>
                <li><a href="">65英寸</a></li>
                <li><a href="">电视配件</a></li>
            </ul>
        </dd>
    </dl>
    <dl>
        <dt><a href=""><strong>电视 </strong> <i></i></a>
        </dt>
        <dd>
            <ul class="product_nav_lists">
                <li><a href="">超薄电视</a></li>
                <li><a href="">全面屏电视</a></li>
                <li><a href="">智能电视</a></li>
                <li><a href="">教育电视</a></li>
                <li><a href="">OLED电视</a></li>
                <li><a href="">智慧屏</a></li>
                <li><a href="">4K超清电视</a></li>
                <li><a href="">55英寸</a></li>
                <li><a href="">65英寸</a></li>
                <li><a href="">电视配件</a></li>
            </ul>
        </dd>
    </dl>
</div>
<div class="mainpage_items_show_right">
    <ul class="mainpage_items_show_img">
        <li>
            <a href=""><img src="./images/p1.webp" alt="231"></a>
        </li>
        <li>
            <a href=""><img src="./images/p2.webp" alt=""></a>
        </li>
        <li>
            <a href=""><img src="./images/p3.webp" alt=""></a>
        </li>
        <li>
            <a href=""><img src="./images/p4.webp" alt=""></a>
        </li>
        <li>
            <a href=""><img src="./images/p5.webp" alt=""></a>
        </li>
        <li>
            <a href=""><img src="./images/p6.webp" alt=""></a>
        </li>
        <li>
            <a href=""><img src="./images/p7.webp" alt=""></a>
        </li>
        <li>
            <a href=""><img src="./images/p8.webp" alt=""></a>
        </li>
    </ul>
    <ul class="mainpage_items_show_img2">
        <li>
            <a href=""><img src="./images/j1.webp" alt=""></a>
        </li>
        <li>
            <a href=""><img src="./images/j2.webp" alt=""></a>
        </li>
    </ul>
</div>
</div>
    `
})